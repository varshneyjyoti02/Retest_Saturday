package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileNumberNotMatchedException;

public interface AccountService {

	Account getAccountDetails(String mobileNo) throws MobileNumberNotMatchedException;

	double rechargeAccount(String mobileNo, double rechargeAmount);

}
