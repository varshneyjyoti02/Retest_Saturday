package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.MobileNumberNotMatchedException;

public class AccountServiceImpl implements AccountService {

	AccountDao dao = new AccountDaoImpl(); // creating object of dao layer

	// method to call dao layer reference to retrieve sales details from database
	@Override
	public Account getAccountDetails(String mobileNo) throws MobileNumberNotMatchedException {

		if (dao.getAccountDetails(mobileNo) == null)
			throw new MobileNumberNotMatchedException();
		return dao.getAccountDetails(mobileNo);
	}

	// method to call dao layer reference to recharges the mobile no given by the user
	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {

		return dao.rechargeAccount(mobileNo, rechargeAmount);
	}

}
