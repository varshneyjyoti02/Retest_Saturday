package com.cg.mra.ui;

import java.util.Scanner;
import java.util.regex.Pattern;
import com.cg.mra.exception.MobileNumberNotMatchedException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {

	public static void main(String[] args) {

		AccountService service = new AccountServiceImpl(); // creating object of service layer

		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in); // creating object of Scanner class

		while (true) {
			// Menu to perform various operations by the user
			System.out.println("**********Mobile Recharge Application**********");
			System.out.println("Enter your choice");
			System.out.println("1. Account Balance Enquiry");
			System.out.println("2. Recharge Account");
			System.out.println("3. Exit");

			int choice = scanner.nextInt();
			scanner.nextLine();

			switch (choice) {
			case 1:
				// Account Balance Enquiry
				System.out.println("Enter your mobile number");
				String mobileNumber = scanner.nextLine();

				while (!(validateMobileNumber(mobileNumber))) // validate 10 digit mobile no
				{
					System.out.println("Enter a valid 10 digit number: ");
					mobileNumber = scanner.next();
				}

				try {
					System.out.println("Your Current Balance is Rs. "
							+ service.getAccountDetails(mobileNumber).getAccountBalance());// display current balance
																							// according to mobile
																							// number
				} catch (MobileNumberNotMatchedException e1) {
					System.out.println(e1.getMessage());
				}
				System.out.println();
				break;
			case 2:
				// Recharge Account
				System.out.println("Enter mobile No");
				String mobileNumber1 = scanner.next();

				while (!(validateMobileNumber(mobileNumber1))) // validate 10 digit mobile no
				{
					System.out.println("Enter a valid 10 digit number: ");
					mobileNumber1 = scanner.next();
				}

				System.out.println("Enter amount");
				double rechargeAmount = scanner.nextInt();

				while (!(validateRechargeAmount(rechargeAmount))) // validate recharge amount is greater than 0
				{
					System.out.println("Enter a valid recharge amount: ");
					rechargeAmount = scanner.nextDouble();
				}

				System.out.println("Account Recharged Successfully");
				try {
					System.out.println("Hello " + service.getAccountDetails(mobileNumber1).getCustomerName() + ", "
							+ "Available Balance is " + service.rechargeAccount(mobileNumber1, rechargeAmount)); //display details of user according to entered phone no and update the recharge amount
				} catch (MobileNumberNotMatchedException e) {
					System.out.println(e.getMessage());
				}
				System.out.println();

				break;
			case 3:
				// Exit
				System.exit(0);
				break;
			}

		}

	}

	// method validate 10 digit mobile no
	private static boolean validateMobileNumber(String mobileNumber) {
		if (Pattern.matches("(0/91)?[7-9][0-9]{9}", mobileNumber)) {
			return true;
		}
		return false;

	}

	// method validate recharge amount is greater than 0
	public static boolean validateRechargeAmount(double rechargeAmount) {
		if (rechargeAmount > 0) {
			return true;
		}
		return false;
	}

}
