package com.cg.mra.test;

import org.junit.Before;
import org.junit.Test;

import com.cg.mra.exception.MobileNumberNotMatchedException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;
import com.cg.mra.ui.MainUI;

public class AccountTest {

		
		MainUI main; //creating reference of Main Class
		AccountService service=new AccountServiceImpl(); //creating object of dao layer


		@Before
		public void setUp() throws Exception {
		}
         
		//to check if mobile number exists in database or not
		@Test(expected=com.cg.mra.exception.MobileNumberNotMatchedException.class)
		public void mobileNoNotMatched() throws MobileNumberNotMatchedException {
			
			service.getAccountDetails("7217499041");
		}
		
		//to check the program successfully runs
		@Test
		public void successfulRun() throws MobileNumberNotMatchedException {
			
			service.getAccountDetails("9010210131");
			service.rechargeAccount("9010210131", 200);
		}
		
		@SuppressWarnings("static-access")
		
		//to check if recharge amount is valid or not
		@Test
		public void RechargeCannotBeDone() {
			double rechargeAmount=0;
			main.validateRechargeAmount(rechargeAmount);
		}
		
		

	}


