package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.cg.mra.beans.Account;

public class AccountDaoImpl implements AccountDao {

	// Account Collection Database
	Map<String, Account> accountEntry;

	public AccountDaoImpl() {
		accountEntry = new HashMap<>();
		accountEntry.put("9010210131", new Account("Prepaid", "Vaishali", 200));
		accountEntry.put("9823920123", new Account("Prepaid", "Megha", 453));
		accountEntry.put("9932012345", new Account("Prepaid", "Vikas", 631));
		accountEntry.put("9010219131", new Account("Prepaid", "Anju", 521));
		accountEntry.put("9010210132", new Account("Prepaid", "Tushar", 632));//there is duplicate values in the question paper so I have changed the mobile number here
	}

	// Method to retrieve account details from the database
	@Override
	public Account getAccountDetails(String mobileNo) {
		for (Entry<String, Account> entry : accountEntry.entrySet()) {

			Account a = entry.getValue();
			if (entry.getKey().equals(mobileNo)) {
				return a;
			}
		}
		return null;
	}

	// Method to recharges account according to the mobile no given by the user
	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		
		for (Entry<String, Account> entry : accountEntry.entrySet()) {

			Account a = entry.getValue();
			if (entry.getKey().equals(mobileNo)) {
				a.setAccountBalance(a.getAccountBalance() + rechargeAmount);
				return a.getAccountBalance();
			}
		}
		return 0;
	}

}
