package com.cg.mra.exception;

@SuppressWarnings("serial")
public class MobileNumberNotMatchedException extends Exception {

	public String getMessage() {
		return "ERROR: Given Account Id Does Not Exists.";
	}

}
