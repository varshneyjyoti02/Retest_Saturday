package com.cg.mra.beans;

public class Account {
	private String mobileNo; // Customer Mobile Number
	private String accountType; // Customer Account Type
	private String customerName; // Customer Name
	private double accountBalance; // Customer Account Balance

	// Getter and Setter of Member Variables of Account class
	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	// Constructor of Account class
	public Account(String accountType, String customerName, double accountBalance) {
		super();
		this.accountType = accountType;
		this.customerName = customerName;
		this.accountBalance = accountBalance;
	}

	public Account() {
		super();

	}

	@Override
	public String toString() {
		return "Account [mobileNo=" + mobileNo + ", accountType=" + accountType + ", customerName=" + customerName
				+ ", accountBalance=" + accountBalance + "]";
	}

}
